/**
 * 
 */
/**
 * @author alvar
 *
 */
module Actividad_7_AbstractFactory {
}