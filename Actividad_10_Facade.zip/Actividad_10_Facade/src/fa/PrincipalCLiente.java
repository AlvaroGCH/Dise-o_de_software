package fa;

public class PrincipalCLiente {

	public static void main(String[] args) {
		facade impresora = new facade();
		
		impresora.visualiza();
	}

}
