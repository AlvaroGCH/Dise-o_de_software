package ad;

public class MotorComun extends Motor{
    public MotorComun(){
        super();
    }

    public void encender(){
        System.out.println("Encendiendo motor común.");
    }

    public void acelerar(){
        System.out.println("Acelerando motor común.");
    }

    public void apagar(){
        System.out.println("Apagando motor común.");
    }
}
