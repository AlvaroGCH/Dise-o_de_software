package ad;

public abstract class Motor{
    abstract public void encender();
    abstract public void acelerar();
    abstract public void apagar();
}