/**
 * 
 */
/**
 * @author alvar
 *
 */
module Actividad_8_TemplateMethod {
}